package com.demo.SpringBootRestWebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
