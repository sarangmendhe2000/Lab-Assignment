package com.demo.SpringBootRestWebservice.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface LoginDao {

}
