package com.demo.MySpringbootRestWebService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringbootRestWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySpringbootRestWebServiceApplication.class, args);
	}

}
