package com.demo.MySpringbootRestWebService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringbootRestWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
